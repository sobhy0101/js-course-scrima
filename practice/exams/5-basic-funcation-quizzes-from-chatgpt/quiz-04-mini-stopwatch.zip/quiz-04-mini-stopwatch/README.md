# Quiz 04 — Mini Stopwatch

Install and run:

```
npm install
npm start
```

## Your Tasks

1. Implement Start, Stop, and Reset for a stopwatch shown in `#time` (format mm:ss.ms).
2. Use `setInterval` or `requestAnimationFrame` to update smoothly.
3. Disable **Start** while running; enable **Stop** only when running.
4. Store lap times into the `<ul id="laps">` when **Lap** is pressed.
5. Clear laps when Reset is pressed.


> JS file is intentionally empty. Add your code in `index.js`.

---
Built for Scrimba-style DOM practice.
