# Quiz 05 — Todo Skeleton

Install and run:

```
npm install
npm start
```

## Your Tasks

1. Add items from `#todo-input` to the list when **Add** is clicked (ignore empty).
2. Clicking a list item toggles a `done` class.
3. Add a small **x** button on each item to remove it.
4. Persist the list in localStorage and restore on load.
5. Add a **Clear All** button that wipes the list + storage.


> JS file is intentionally empty. Add your code in `index.js`.

---
Built for Scrimba-style DOM practice.
