# Quiz 03 — Color Switcher

Install and run:

```
npm install
npm start
```

## Your Tasks

1. When any swatch is clicked, update `document.body` background and `#name` with the color name.
2. Implement a **Random** button that picks a random swatch color.
3. Implement a **Copy** button that copies the current color to the clipboard.
4. Persist the last chosen color in localStorage and restore on load.
5. Bonus: Keyboard left/right arrows cycle through swatches.


> JS file is intentionally empty. Add your code in `index.js`.

---
Built for Scrimba-style DOM practice.
