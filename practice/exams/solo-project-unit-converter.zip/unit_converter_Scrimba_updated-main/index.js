const inputEl = document.getElementById('valueInput');
const convertBtn = document.getElementById('convertBtn');
const resetBtn = document.getElementById('resetBtn');
const lengthResult1 = document.getElementById('lengthResult1');
const lengthResult2 = document.getElementById('lengthResult2');
const volumeResult1 = document.getElementById('volumeResult1');
const volumeResult2 = document.getElementById('volumeResult2');
const massResult1 = document.getElementById('massResult1');
const massResult2 = document.getElementById('massResult2');

// Conversions
const conversionRates = {
    meterToFeet: 3.281,
    feetToMeter: 0.304,
    literToGallon: 0.264,
    gallonToLiter: 3.785,
    kiloToPound: 2.204,
    poundToKilo: 0.454
};

// Helper function to handle singular/plural
function getUnit(value, singular, plural) {
    return value === 1 ? singular : plural;
}

convertBtn.addEventListener('click', function() {
    const value = parseFloat(inputEl.value);
    
    if (isNaN(value)) {
        lengthResult1.textContent = '';
        lengthResult2.textContent = '';
        volumeResult1.textContent = '';
        volumeResult2.textContent = '';
        massResult1.textContent = '';
        massResult2.textContent = '';
        return;
    }

    // Length conversion
    const feetResult = (value * conversionRates.meterToFeet).toFixed(3);
    const meterResult = (value * conversionRates.feetToMeter).toFixed(3);
    
    lengthResult1.textContent = `${value} ${getUnit(value, 'meter', 'meters')} = ${feetResult} ${getUnit(parseFloat(feetResult), 'foot', 'feet')} | `;
    lengthResult2.textContent = `${value} ${getUnit(value, 'foot', 'feet')} = ${meterResult} ${getUnit(parseFloat(meterResult), 'meter', 'meters')}`;

    // Volume conversion
    const gallonResult = (value * conversionRates.literToGallon).toFixed(3);
    const literResult = (value * conversionRates.gallonToLiter).toFixed(3);
    
    volumeResult1.textContent = `${value} ${getUnit(value, 'liter', 'liters')} = ${gallonResult} ${getUnit(parseFloat(gallonResult), 'gallon', 'gallons')} | `;
    volumeResult2.textContent = `${value} ${getUnit(value, 'gallon', 'gallons')} = ${literResult} ${getUnit(parseFloat(literResult), 'liter', 'liters')}`;

    // Mass conversion
    const poundResult = (value * conversionRates.kiloToPound).toFixed(3);
    const kiloResult = (value * conversionRates.poundToKilo).toFixed(3);
    
    massResult1.textContent = `${value} ${getUnit(value, 'kilo', 'kilos')} = ${poundResult} ${getUnit(parseFloat(poundResult), 'pound', 'pounds')} | `;
    massResult2.textContent = `${value} ${getUnit(value, 'pound', 'pounds')} = ${kiloResult} ${getUnit(parseFloat(kiloResult), 'kilo', 'kilos')}`;
});

resetBtn.addEventListener('click', function() {
    inputEl.value = '';
    lengthResult1.textContent = '';
    lengthResult2.textContent = '';
    volumeResult1.textContent = '';
    volumeResult2.textContent = '';
    massResult1.textContent = '';
    massResult2.textContent = '';
});  