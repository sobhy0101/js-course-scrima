updated scrimba metric/imperial unit converter using HTML, CSS and JS 
